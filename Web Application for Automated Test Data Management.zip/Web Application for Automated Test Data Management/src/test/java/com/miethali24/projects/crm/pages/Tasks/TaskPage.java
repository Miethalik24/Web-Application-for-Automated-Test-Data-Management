package com.anhtester.projects.crm.pages.Tasks;

public class TaskPage {

    public TaskPage() {

    }

}
