package com.anhtester.projects;

import com.anhtester.helpers.SystemHelpers;
import com.anhtester.utils.LogUtils;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class App {
    public static void main(String[] args) throws IOException, InterruptedException {
        LogUtils.info("Build success !!");
    }
}
