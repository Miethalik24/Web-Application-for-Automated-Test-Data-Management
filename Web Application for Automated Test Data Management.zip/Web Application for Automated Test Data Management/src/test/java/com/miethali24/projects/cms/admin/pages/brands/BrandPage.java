package com.anhtester.projects.cms.admin.pages.brands;

public class BrandPage {
}
