package com.anhtester.enums;

/**A Java Enum is a special Java type used to define collections of constants.*/
public enum CategoryType {
	REGRESSION, 
	SMOKE, 
	SANITY
}